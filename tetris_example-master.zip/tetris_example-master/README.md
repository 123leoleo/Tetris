Ein sicheres Passwort:

Bitte gebe Dein Passwort ein. ananas

Entschuldigung, Dein Passwort ist zu kurz! geschaelte ananas

Entschuldigung, Dein Passwort muss mindestens 1 Nummer enthalten 1 geschaelte ananas

Entschuldigung, Dein Passwort darf keine Leerzeichen enthalten. 50verficktegeschaelteananas

Entschuldigung, Dein Passwort muss Grossbuchstaben enthalten. 50VERFICKTEgeschaelteananas

Entschuldigung, Dein Passwort darf nur Grossbuchstaben enthalten, die nicht aufeinanderfolgend sind. 50VerfickteGeschaelteAnanas DieIchDirInDenArschSchiebe, WennDuNichtEndlichDas VerficktePasswortNimmst!!!

Entschuldigung, Dein Passwort darf keine Satzzeiten enthalten. JetztWerdIchLangsamRichtigSauer 50VerfickteGeschaelteAnanas DieIchDirInDenArschSchiebe WennDuNichtEndlichDas VerficktePasswortNimmst

Entschuldigung, das Passwort ist schon in Benutzung. Wähle ein anderes!
